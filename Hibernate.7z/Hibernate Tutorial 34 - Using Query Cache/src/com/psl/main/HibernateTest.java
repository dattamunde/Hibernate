package com.psl.main;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.psl.bean.Address;
import com.psl.bean.FourWheeler;
import com.psl.bean.TwoWheeler;
import com.psl.bean.UserDetails;
import com.psl.bean.Vehicle;

public class HibernateTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure(
				"hibernate.cfg.xml").buildSessionFactory();
		Session session = sessionFactory.openSession();
		sessionFactory.getCurrentSession();
		session.beginTransaction();

		Query query = session.createQuery("from UserDetails user where user.userId = 1").setCacheable(true);
		
		List<UserDetails> list = (List<UserDetails>)query.list();
		for (UserDetails userDetails : list) {
			System.out.println(userDetails);
		}
		// user.setUserName("ganesh");
		session.getTransaction().commit();
		session.close();

		Session session2 = sessionFactory.openSession();
		session2.beginTransaction();

		Query query2 = session2.createQuery("from UserDetails user where user.userId = 1").setCacheable(true);
		List<UserDetails> list2 = (List<UserDetails>)query2.list();
		for (UserDetails userDetails : list2) {
			System.out.println(userDetails);
		}

		session2.getTransaction().commit();
		session2.close();

	}

}
