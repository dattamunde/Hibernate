package com.psl.main;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

import com.psl.bean.Address;
import com.psl.bean.FourWheeler;
import com.psl.bean.TwoWheeler;
import com.psl.bean.UserDetails;
import com.psl.bean.Vehicle;

public class HibernateTest {
	public static void main(String[] args) {
		UserDetails userDetails = new UserDetails();
		userDetails.setUserName("datta");
		UserDetails userDetails2 = new UserDetails();
		userDetails2.setUserName("munde");

		Session session = new Configuration().configure("hibernate.cfg.xml")
				.buildSessionFactory().openSession();
		session.beginTransaction();

		String minUserId = "5";
		String userName = "datta";
		Query query = session
				.createQuery("from UserDetails where userId > :userId and userName = :userName");
		query.setInteger("userId", Integer.parseInt(minUserId));
		query.setString("userName", userName);
		List<UserDetails> list = (List<UserDetails>) query.list();

		for (UserDetails userDetails3 : list) {
			System.out.println(userDetails3);
		}
		session.getTransaction().commit();
		session.close();

	}

}
