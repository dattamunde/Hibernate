package com.psl.main;

import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

import com.psl.bean.Address;
import com.psl.bean.UserDetails;

public class HibernateTest {
	public static void main(String[] args) {
		UserDetails userDetails=new UserDetails();
		userDetails.setUserId(2);
		userDetails.setUserName("datta");
		
		Address address=new Address();
		address.setStreet("a");
		address.setCity("Parli");
		address.setState("MH");
		address.setPincode("431515");
		
		
		userDetails.getListOfAddresses().add(address);
		
		Session session = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory().openSession();
		session.beginTransaction();
		session.save(userDetails);
		session.getTransaction().commit();
	}
	
}
