package com.psl.main;

import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

import com.psl.bean.Address;
import com.psl.bean.UserDetails;
import com.psl.bean.Vehicle;

public class HibernateTest {
	public static void main(String[] args) {
		UserDetails userDetails=new UserDetails();
		userDetails.setUserId(1);
		userDetails.setUserName("datta");
		
//		Address address=new Address();
//		address.setStreet("a");
//		address.setCity("Parli");
//		address.setState("MH");
//		address.setPincode("431515");
		
		Vehicle vehicle=new Vehicle();
		vehicle.setVehicleName("Bike");
		userDetails.setVehicle(vehicle);
		
		Vehicle vehicle2=new Vehicle();
		vehicle2.setVehicleName("Car");
		userDetails.setVehicle(vehicle2);
		
//		userDetails.setVehicle(vehicle);
		
		Session session = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory().openSession();
		session.beginTransaction();
		session.save(userDetails);
		session.save(vehicle);
		session.save(vehicle2);
		session.getTransaction().commit();
	}
	
}
