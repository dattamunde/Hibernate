package com.psl.main;

import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

import com.psl.bean.Address;
import com.psl.bean.UserDetails;
import com.psl.bean.Vehicle;

public class HibernateTest {
	public static void main(String[] args) {
		UserDetails userDetails=new UserDetails();
//		userDetails.setUserId(6);
		userDetails.setUserName("datta");
		
		UserDetails userDetails2=new UserDetails();
//		userDetails2.setUserId(7);
		userDetails2.setUserName("datta");
		
		Address address=new Address();
		address.setStreet("a");
		address.setCity("Parli");
		address.setState("MH");
		address.setPincode("431515");
		
		Vehicle vehicle=new Vehicle();
		vehicle.setVehicleName("Bike");
		userDetails.getVehicles().add(vehicle);
		vehicle.setUser(userDetails);
		
		Vehicle vehicle2=new Vehicle();
		vehicle2.setVehicleName("Car");
		userDetails2.getVehicles().add(vehicle2);
		vehicle2.setUser(userDetails2);
		Session session = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory().openSession();
		session.beginTransaction();
		session.save(userDetails);
		session.save(userDetails2);
		session.save(vehicle);
		session.save(vehicle2);
		session.getTransaction().commit();
	}
	
}
