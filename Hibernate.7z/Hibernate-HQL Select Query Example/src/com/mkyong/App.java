package com.mkyong;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

import com.mkyong.stock.Stock;

public class App {
	public static void main(String[] args) {
		System.out.println("Hibernate many to many (Annotation)");
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		Session session = configuration.buildSessionFactory().openSession();

		session.beginTransaction();

		Stock stock = new Stock();
        stock.setStockCode("7052");
        stock.setStockName("PADINI");
        
        session.save(stock);
    
		session.getTransaction().commit();
		System.out.println("Done");
	}
}
