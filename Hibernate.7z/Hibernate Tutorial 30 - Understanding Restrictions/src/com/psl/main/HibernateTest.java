package com.psl.main;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.psl.bean.Address;
import com.psl.bean.FourWheeler;
import com.psl.bean.TwoWheeler;
import com.psl.bean.UserDetails;
import com.psl.bean.Vehicle;

public class HibernateTest {
	public static void main(String[] args) {
		Session session = new Configuration().configure("hibernate.cfg.xml")
				.buildSessionFactory().openSession();
		session.beginTransaction();
		
		Criteria criteria = session.createCriteria(UserDetails.class);
//		criteria.add(Restrictions.eq("userName", "datta")).add(Restrictions.ge("userId", 0));
		criteria.add(Restrictions.or(Restrictions.eq("userName", "datta"), Restrictions.between("userId", 0, 3)));
		
		List<UserDetails> list = (List<UserDetails>)criteria.list();
		for (UserDetails userDetails : list) {
			System.out.println(userDetails);
		}
		session.getTransaction().commit();
		session.close();

	}

}
