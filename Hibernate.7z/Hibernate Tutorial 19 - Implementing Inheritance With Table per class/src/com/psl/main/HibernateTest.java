package com.psl.main;

import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

import com.psl.bean.Address;
import com.psl.bean.FourWheeler;
import com.psl.bean.TwoWheeler;
import com.psl.bean.UserDetails;
import com.psl.bean.Vehicle;

public class HibernateTest {
	public static void main(String[] args) {
		Vehicle vehicle=new Vehicle();
//		vehicle.setVehicleId(vehicleId);
		vehicle.setVehicleName("Car");
		
		TwoWheeler twoWheeler=new TwoWheeler();
//		twoWheeler.setVehicleName("Splender plus");
//		twoWheeler.setSteeringHandle("steeringHandle");
		
		FourWheeler fourWheeler = new FourWheeler();
//		fourWheeler.setVehicleName("Maruti");
//		fourWheeler.setSteeringWheel("steeringWheel");
		
		
		Session session = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory().openSession();
		session.beginTransaction();
		session.save(vehicle);
		session.save(twoWheeler);
		session.save(fourWheeler);
		session.getTransaction().commit();
	}
	
}
