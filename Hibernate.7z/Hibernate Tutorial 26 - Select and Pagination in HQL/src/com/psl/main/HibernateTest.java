package com.psl.main;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

import com.psl.bean.Address;
import com.psl.bean.FourWheeler;
import com.psl.bean.TwoWheeler;
import com.psl.bean.UserDetails;
import com.psl.bean.Vehicle;

public class HibernateTest {
	public static void main(String[] args) {
		UserDetails userDetails=new UserDetails();
		userDetails.setUserName("datta");
		UserDetails userDetails2=new UserDetails();
		userDetails2.setUserName("munde");
		
		Session session = new Configuration().configure("hibernate.cfg.xml")
				.buildSessionFactory().openSession();
		session.beginTransaction();

		Query query = session.createQuery("select userName from UserDetails");
		query.setFirstResult(1);
		query.setMaxResults(5);
		List<String> list = (List<String>)query.list();
		
		for (String userDetails3 : list) {
			System.out.println(userDetails3);
		}
		
		session.getTransaction().commit();
		session.close();
		
	}

}
