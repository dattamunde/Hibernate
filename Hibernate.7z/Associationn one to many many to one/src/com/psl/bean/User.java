package com.psl.bean;

import java.util.HashSet;
import java.util.Set;

public class User {
	private int userid;
	private String userName;
	private Set<Contact> contact=new HashSet<Contact>();
	
	public User() {
		// TODO Auto-generated constructor stub
	}
	public User(int userid, String userName, Set<Contact> contact) {
		super();
		this.userid = userid;
		this.userName = userName;
		this.contact = contact;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Set<Contact> getContact() {
		return contact;
	}
	public void setContact(Set<Contact> contact) {
		this.contact = contact;
	}
	
	
}
