package com.psl.main;

import java.sql.Date;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

import com.psl.bean.Address;
import com.psl.bean.Contact;
import com.psl.bean.User;

public class Main {

	public static void main(String[] args) {
		
		
		
		
		//transient
		Set<String> s1=new HashSet<String>(Arrays.asList("6513","56843564","6842351"));
		Contact c1 = new Contact("aditya", "pawaskar", "ap@gmail.com", Date.valueOf("2016-05-02"),new HashSet<Address>(Arrays.asList(new Address("pune", "ind"),new Address("mum", "aslk"))),s1);
		Contact c2 = new Contact("mihir", "desai", "mihir@gmail.com", Date.valueOf("2012-05-02"),new HashSet<Address>(Arrays.asList(new Address("city2", "country2"),new Address("sldm", "ind"))),new HashSet<String>(Arrays.asList("6513","568464","64351")));
		Contact c3 = new Contact("datta", "pawaskar", "a1p@gmail.com", Date.valueOf("2016-05-02"),new HashSet<Address>(Arrays.asList(new Address("pune", "ind"),new Address("mum", "aslk"))),s1);
		Contact c4 = new Contact("munde", "desai", "mihir1@gmail.com", Date.valueOf("2012-05-02"),new HashSet<Address>(Arrays.asList(new Address("city2", "country2"),new Address("sldm", "ind"))),new HashSet<String>(Arrays.asList("6513","568464","64351")));
		Contact c5 = new Contact("ganesh", "pawaskar", "ap2@gmail.com", Date.valueOf("2016-05-02"),new HashSet<Address>(Arrays.asList(new Address("pune", "ind"),new Address("mum", "aslk"))),s1);
		Contact c6 = new Contact("abc", "desai", "mihir@gma2il.com", Date.valueOf("2012-05-02"),new HashSet<Address>(Arrays.asList(new Address("city2", "country2"),new Address("sldm", "ind"))),new HashSet<String>(Arrays.asList("6513","568464","64351")));
		Contact c7 = new Contact("pqr", "pawaskar", "ap@gmai3l.com", Date.valueOf("2016-05-02"),new HashSet<Address>(Arrays.asList(new Address("pune", "ind"),new Address("mum", "aslk"))),s1);
		Contact c8 = new Contact("kscjh", "desai", "mihir@gma3il.com", Date.valueOf("2012-05-02"),new HashSet<Address>(Arrays.asList(new Address("city2", "country2"),new Address("sldm", "ind"))),new HashSet<String>(Arrays.asList("6513","568464","64351")));
		Contact c9 = new Contact("an;dfjkl", "pawaskar", "ap@g4mail.com", Date.valueOf("2016-05-02"),new HashSet<Address>(Arrays.asList(new Address("pune", "ind"),new Address("mum", "aslk"))),s1);
		Contact c10 = new Contact("kkdfjknj", "desai", "mihir@g5mail.com", Date.valueOf("2012-05-02"),new HashSet<Address>(Arrays.asList(new Address("city2", "country2"),new Address("sldm", "ind"))),new HashSet<String>(Arrays.asList("6513","568464","64351")));
		
		User user1=new User();
		User user2=new User();
		User user3=new User();
		User user4=new User();
		User user5=new User();
		
		user1.getContact().add(c1);
		user1.getContact().add(c2);
		user1.getContact().add(c3);
		user1.getContact().add(c4);
		
		user2.getContact().add(c5);
		user2.getContact().add(c6);
		user2.getContact().add(c7);
		
		user3.getContact().add(c8);
		user3.getContact().add(c9);
		user3.getContact().add(c10);
		
		
		Configuration conf = new Configuration().configure();

		SessionFactory sf;
		sf = conf.buildSessionFactory();

		Session session;
		session = sf.openSession();

		Transaction tx = session.beginTransaction();

		session.save(user1);
		for (Contact string : user1.getContact()) {
			session.save(string);
		}
		session.save(user2);
		for (Contact string : user2.getContact()) {
			session.save(string);
		}
		session.save(user3);
		for (Contact string : user3.getContact()) {
			session.save(string);
		}
		session.save(user4);
		for (Contact string : user4.getContact()) {
			session.save(string);
		}
		session.save(user5);
		for (Contact string : user5.getContact()) {
			session.save(string);
		}
		
		tx.commit();
//		
//		session.close();
//		
//		sf.close();
		
	}

}
